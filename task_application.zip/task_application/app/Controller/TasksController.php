<?php
class TasksController extends AppController{
	
	var $name='Tasks';
	var $scaffold;
	
}
?>