<?php
class Main extends AppModel
{
	var $name=Main;
}
?>