<?php
class Task extends AppModel
{
	var $name='Task';
	var $useTable='tasks';/*** Table Name ***/
	
}
?>